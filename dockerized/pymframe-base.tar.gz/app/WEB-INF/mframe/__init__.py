"""
Dieses Package enthaelt die Klassen des Frameworks

"""