class Version:
   """
   Updates:
   --------
   0.10  11.02.2011
         Checktype als eingen Klasse gemacht
         Dateconverter entwickelt
         Untitest ausgebaut

   0.20  ORACLE Unterstuezung eingebaut

   0.21  16.05.2012
         Verbesserung in der Taglib

   0.3   18.05.2012
         addEntry um addparam erweitert

   0.4   11.06.2012
         Bugfix im dbaccess und taglib

   0.5   Viewhandler
         Bugfix

   0.6   Aenderung im Menu
         Option display [True | False]
         Im Controller kann dies Umgesetzt werden.
         Siehe Details im menu.py

   0.6.1 Grid Layout
         im Viewhandler

   0.7   Handler im Domain eingebaut

   0.8   Bugfix in dbaccess.core
         0.8.3 + Viewhandler
                 Einbau der Mehode nextDomain um mit
                 Fehler bei der Datenbank umzugehen.
               + database.core
                 Bugfix
         0.8.5 Oracle spezielle Insert
               Oracle spezielle update
   0.9   Release Candidat
         Oracle support verbessert
         0.9.1       in der eachDomain limit eingebaut
         0.9.2       bei dbaccess methode get bugfix
         0.9.3       Paginate in viewhandler
         0.9.4       Vebesserungen im MySQL Handling
         0.9.5       Sendfile (experimentell)
         0.9.6       Bugfix
         0.9.7       Optimierung bei Viewhandler
         0.9.8       Anpassung mySQL Datumsformat (dateconverter)
         0.9.9       + Layouts und minor Bugfixes
                     + Bugfix in viewhandler
         0.9.10      redirect eingebaut
         0.9.11      Flash angepasst
         0.9.12      Kleine Anpassungen
         0.9.13      Bug bei setContainer entfernt
         0.9.14      Verzeichnis "mvc" kann global installiert sein.
         0.9.15      CSS Klassen in TD eingebaut
         0.9.16      In Menue 'id' und 'titel' eingabaut
                     CSS support in Menueeintraegen verbessert.
         0.9.17      Autocommit bei mySQL eingebaut
         0.9.18      Verbesserte Fehlermeldung in der Controller Klasse

         0.9.19      ORA Date
         0.9.20      ORA Insert bugfix
                     ORA NLS_LANG eingebaut
         0.9.21      Taglib Anpassungen auf IE8
                     Bei Dateconverter Kommans und Blanks im Datumsstring erlaubt
         0.9.3       Json fuer dbAccess
         0.9.31      Fehler in dateconverter gefixed
                     refactoring: == None -> is None != None -> is not None
         0.9.4       In dbaccess den Datentyp long eingefuehrt
         0.9.5       + Verbesserte Anzeige wenn ungueltiger Pfad (path) im Aufruf
                     + Verbesserte Anzeige wenn unberechtigter Controlleraufruf
                     + r/w Rechte (z.B. read:r)
         0.9.51      In Authen Readonly Kennung (xxx:r) eingebaut (isWriteable)
         0.9.51a-..  Bugfixes
         0.9.6       Einbau von Formatierungsmoeglichkeiten bei Menueanzeige
         0.9.6a      Bei Sender.sendfile wurde option delete eingebaut
         0.9.7       Bug in JSON convert in eachDomain
         0.9.8       Config wird ueber Main in alle abgeleitete Klassen weitergeleitet
         0.9.9       In Domain wurde eine Routine zur Umwandlung aller gelesenenr Felder
                     in einen gewuenschten Characterset eingebaut, Beispiel: cvtCharset('utf9','latin1')
         0.9.10      Javascript Events in Taglib, promptinput
         0.9.11      + Domain sqlite lastAutoincrement
                     + Viewhander, bei run Option show=False,
                       verhindert die Ausgabe des Ergebnisses
         0.9.12      Fehler bei menuebase bei @url behoben
         0.9.20      Translation
                     Einbau der Klasse Translat
                     Diese Klasse ermoeglicht die Uebersetzung aus einer INI Datei
                     Siehe naehre Informationen in der Klasse
         0.9.21      Bugfix in menubase.py
         0.9.22      Bei LISTEDIT wurde das Verhalten so geaendert,
                     dass nach dem Aendern wieder die Bearbeitungsmaske angezeigt
                     wird. Dies kann durch das Flag keepEdit = [True|False] beeinflusst werden.
         0.9.23      Verbesserung des Verhaltens bei keepEdit und EDIT-LAYOUT
                    
         0.9.24      Anpassungen taglib auf HTML5
         0.9.25      Fuer xDem Import wurde bei Domain (dbaccess.core) die Umewandlungsroutine
                     fuer als String uebergebene Doamin Variable herausgeloest um 
                     extern verwendet werden zu koennen
                     prepareValue (fld,value)
                        + fld          Feldname
                        + value        Inhalt
                     Wenn Ein Fehler auftritt, wird self.hasErrors gesetzt

                     in mframe xdembase.py erweitert.         
        0.9.26       in Controller writelog eingefuert.+
                     usage self.writelog('logmessage')
                     Schreibt den Angegebenen Text auf syserr

        0.9.27       onMouseover von save in speichern geaendert.
                     Verbesserte weitergabe von Type-Fehlermeldung in viewer

        0.9.28       Bei Datevonverter die Fehlende Konvertierung CCYY-MM-DD MI:SC eingebaut.

        0.9.29       onWrite wird unmitelbar nach onDelete, onUpdate und onInsert
                     ausgefuehrt.
                     dbaccess -> core Problem behoben wenn Tabelle keine
                     Autoincrement hat bei lastAutoincrement.
        0.9.30       Menubase:
                     einbau einer Moeglichkeit den Controller Eintrag in 
                     einem Menueentry zu aenderb bzw. zur Laufzeit anzugeben
                     setEntryController
        0.9.31       Viewhandler
                     Verbesesrte Erkennung fuer Listendarstellung
        0.9.4        Erweiterung von Sidebox auf mehere Ebenen

        0.9.5        Verbesserung der Rechte hinsichtlich
                     in Verbindung mit Readonly (recht:r)
        0.9.6        Bei translate wird bei Multiline die Leerzeilen
                     enthalten mit "." (Punkt) markiert.

        0.9.7        Verbesserung bei Sender Klasse
                     Anpassung an Win32 Umgebung
        0.9.8        afterRead event
                     bei Domain.get und eachDomain eingebaut.
                     Wird nach jedem lesen aufgerufen.
        0.9.9        Ermoeglicht das notieren von negativen Rechten
                     wird in Menue -xxx notiert so wird die 
                     Funktion nicht aufgerufen, wenn der Benutzer das
                     recht xx hat.
        0.9.10       Direktes Zuweisen von Date Feldern bei ORACLE DB
                     wenn von ANSI in Datetime umgewandelt wurde geloest
        0.9.11       Bugfix: in taglib style Attribute eingebaut

        0.9.12       Einfuehrung von pbkdf2 Passwortverschluesselung

   """
   VERSION = '0.9.12'