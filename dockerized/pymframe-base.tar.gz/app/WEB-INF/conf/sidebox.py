# -*- coding: iso-8859-15 -*-
from sideboxbase import SideboxBase

# ### KONFIGURATION
#
class Sidebox(SideboxBase):
   pass
