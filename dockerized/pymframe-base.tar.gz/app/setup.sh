#! /usr/sh
chmod -R +x ./scripts
chmod -R 777 ./WEB-INF/datastore
